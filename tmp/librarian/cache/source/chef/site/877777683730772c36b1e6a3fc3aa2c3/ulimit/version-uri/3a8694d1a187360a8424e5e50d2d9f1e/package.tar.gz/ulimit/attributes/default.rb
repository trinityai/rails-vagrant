default['ulimit']['pam_su_template_cookbook'] = nil
default['ulimit']['users'] = Mash.new
